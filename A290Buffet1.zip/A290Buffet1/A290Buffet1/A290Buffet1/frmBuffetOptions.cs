﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A290Buffet1
{
    public partial class frmBuffetOptions : Form
    {
        public frmBuffetOptions()
        {
            InitializeComponent();
        }

        private void btnOptions_Click(object sender, EventArgs e)
        {
            frmBuffetOptions frmBuffetOptionsDialog = new frmBuffetOptions();
            frmBuffetOptionsDialog.Show();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void optBackgroundBlue_CheckedChanged(object sender, EventArgs e)
        {
            BackColor = Color.Blue;
        }

        private void optBackgroundRed_CheckedChanged(object sender, EventArgs e)
        {
            BackColor = Color.Red;
        }

        private void optBackgroundGreen_CheckedChanged(object sender, EventArgs e)
        {
            BackColor = Color.Green;
        }

        private void optBackgroundGold_CheckedChanged(object sender, EventArgs e)
        {
            BackColor = Color.Gold;
        }

        private void cboBorderColors_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cboBorderColors.Text)
            {
                case "Red":
                    MessageBox.Show("Red was chosen");
                    Graphics objGraphicsRed = null;
                    objGraphicsRed = CreateGraphics();
                    objGraphicsRed.Clear(SystemColors.Control);
                    objGraphicsRed.DrawRectangle(Pens.Red, 1, 1, 281, 258);
                    objGraphicsRed.Dispose();
                    break;

                case "Blue":
                    MessageBox.Show("Blue was chosen");
                    Graphics objGraphicsBlue = null;
                    objGraphicsBlue = CreateGraphics();
                    objGraphicsBlue.Clear(SystemColors.Control);
                    objGraphicsBlue.DrawRectangle(Pens.Blue, 1, 1, 281, 258);
                    objGraphicsBlue.Dispose();
                    break;

                case "Gold":
                    MessageBox.Show("Gold was chosen");
                    Graphics objGraphicsGold = null;
                    objGraphicsGold = CreateGraphics();
                    objGraphicsGold.Clear(SystemColors.Control);
                    objGraphicsGold.DrawRectangle(Pens.Gold, 1, 1, 281, 258);
                    objGraphicsGold.Dispose();
                    break;

                case "Green":
                    MessageBox.Show("Green was chosen");
                    Graphics objGraphicsGreen = null;
                    objGraphicsGreen = CreateGraphics();
                    objGraphicsGreen.Clear(SystemColors.Control);
                    objGraphicsGreen.DrawRectangle(Pens.Green, 1, 1, 281, 258);
                    objGraphicsGreen.Dispose();
                    break;

                default:
                    MessageBox.Show("Back to the Default");
                    Graphics objGraphicsDefault = null;
                    objGraphicsDefault = CreateGraphics();
                    objGraphicsDefault.Clear(SystemColors.Control);
                    objGraphicsDefault.DrawRectangle(Pens.PaleTurquoise, 1, 1, 281, 258);
                    objGraphicsDefault.Dispose();
                    break;
                
                
            }
        }

        private void optBackgroundDefault_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
