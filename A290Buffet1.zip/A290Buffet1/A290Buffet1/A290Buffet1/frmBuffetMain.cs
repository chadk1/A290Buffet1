﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A290Buffet1
{
    public partial class frmBuffetMain : Form
    {
        public frmBuffetMain()
        {
            InitializeComponent();
        }

        const bool defPromptOnExit = true;
        bool blnPromptOnExit = defPromptOnExit;

        private void btnSelectPicture_Click(object sender, EventArgs e)
        {
            if (ofdSelectPicture.ShowDialog() == DialogResult.OK)
            {
                //Load the picture into the picture box
                picShowPicture.Image = Image.FromFile(ofdSelectPicture.FileName);
                //Show  the name of the file in the Form's caption
                Text = string.Concat("A290 Buffet (" + ofdSelectPicture.FileName + ")");
            }
        }

        private void picShowPicture_Click(object sender, EventArgs e)
        {

        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            //Exit our application gracefully
            Close();
        }

        private void btnShrink_Click(object sender, EventArgs e)
        {
            Width = Width + 20;
            Height = Height + 20;
        }

        private void btnEnlarge_Click(object sender, EventArgs e)
        {
            Width = Width - 20;
            Height = Height - 20;
        }

        private void btnDrawBorder_Click(object sender, EventArgs e)
        {
            Graphics objDrawBorder = null;
            objDrawBorder = CreateGraphics();
            objDrawBorder.Clear(SystemColors.Control);
            objDrawBorder.DrawRectangle(Pens.Blue, picShowPicture.Left - 1,
                picShowPicture.Top - 1,
                width: picShowPicture.Width + 1, height: picShowPicture.Height + 1);
            objDrawBorder.Dispose();
        }

        private void picShowPicture_MouseMove(object sender, MouseEventArgs e)
        {
            lblX.Text = "X: " + e.X.ToString();
            lblY.Text = "Y: " + e.Y.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void picShowPicture_MouseLeave(object sender, EventArgs e)
        {
            lblX.Text = "";
            lblY.Text = "";
        }

        private void frmBuffetMain_Load(object sender, EventArgs e)
        {
            lblX.Text = "";
            lblY.Text = "";

            //make our checkbox and boolean match values
            chkPromptExit.Checked = blnPromptOnExit;
        }

        private void btnOptions_Click(object sender, EventArgs e)
        {
            frmBuffetOptions frmBuffetOptionsDialog = new frmBuffetOptions();
            frmBuffetOptionsDialog.Show();
        }

        private void chkPromptExit_CheckedChanged(object sender, EventArgs e)
        {
            //When state of check changes, change boolean
            blnPromptOnExit = (chkPromptExit.Checked);
        }

        private void frmBuffetMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (blnPromptOnExit)
            //if box is checked
            {
                if (MessageBox.Show("Close the Buffet Program?",
                    "Confirm Exit", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.No)

                //display a dialog with Yes/No buttons that asks
                //"Close the Buffet Program?", uses the "?" icon, and has
                //the caption "Confirm Exit" If the user selects "No", then
                {
                    //Cancel the event frmBuffet_FormClosing
                    e.Cancel = true;
                }
                //otherwise, close the application
            }
        }
    }
}
