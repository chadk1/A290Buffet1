﻿namespace Collections
{
    partial class frmCollections
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnShowNames = new System.Windows.Forms.Button();
            this.btnMarge = new System.Windows.Forms.Button();
            this.btnHomer = new System.Windows.Forms.Button();
            this.btnLisa = new System.Windows.Forms.Button();
            this.btnBart = new System.Windows.Forms.Button();
            this.btnMaggie = new System.Windows.Forms.Button();
            this.txtTheSimpsons = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnShowNames
            // 
            this.btnShowNames.Location = new System.Drawing.Point(172, 239);
            this.btnShowNames.Name = "btnShowNames";
            this.btnShowNames.Size = new System.Drawing.Size(120, 23);
            this.btnShowNames.TabIndex = 0;
            this.btnShowNames.Text = "Show Control Names";
            this.btnShowNames.UseVisualStyleBackColor = true;
            this.btnShowNames.Click += new System.EventHandler(this.btnShowNames_Click);
            // 
            // btnMarge
            // 
            this.btnMarge.Location = new System.Drawing.Point(133, 12);
            this.btnMarge.Name = "btnMarge";
            this.btnMarge.Size = new System.Drawing.Size(75, 23);
            this.btnMarge.TabIndex = 1;
            this.btnMarge.Text = "Marge";
            this.btnMarge.UseVisualStyleBackColor = true;
            // 
            // btnHomer
            // 
            this.btnHomer.Location = new System.Drawing.Point(217, 12);
            this.btnHomer.Name = "btnHomer";
            this.btnHomer.Size = new System.Drawing.Size(75, 23);
            this.btnHomer.TabIndex = 2;
            this.btnHomer.Text = "Homer";
            this.btnHomer.UseVisualStyleBackColor = true;
            // 
            // btnLisa
            // 
            this.btnLisa.Location = new System.Drawing.Point(217, 41);
            this.btnLisa.Name = "btnLisa";
            this.btnLisa.Size = new System.Drawing.Size(75, 23);
            this.btnLisa.TabIndex = 3;
            this.btnLisa.Text = "Lisa";
            this.btnLisa.UseVisualStyleBackColor = true;
            // 
            // btnBart
            // 
            this.btnBart.Location = new System.Drawing.Point(133, 41);
            this.btnBart.Name = "btnBart";
            this.btnBart.Size = new System.Drawing.Size(75, 23);
            this.btnBart.TabIndex = 4;
            this.btnBart.Text = "Bart";
            this.btnBart.UseVisualStyleBackColor = true;
            // 
            // btnMaggie
            // 
            this.btnMaggie.Location = new System.Drawing.Point(183, 70);
            this.btnMaggie.Name = "btnMaggie";
            this.btnMaggie.Size = new System.Drawing.Size(75, 23);
            this.btnMaggie.TabIndex = 5;
            this.btnMaggie.Text = "Maggie";
            this.btnMaggie.UseVisualStyleBackColor = true;
            // 
            // txtTheSimpsons
            // 
            this.txtTheSimpsons.Location = new System.Drawing.Point(183, 132);
            this.txtTheSimpsons.Name = "txtTheSimpsons";
            this.txtTheSimpsons.Size = new System.Drawing.Size(100, 20);
            this.txtTheSimpsons.TabIndex = 6;
            this.txtTheSimpsons.Text = "The Simpsons";
            // 
            // frmCollections
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 317);
            this.Controls.Add(this.txtTheSimpsons);
            this.Controls.Add(this.btnMaggie);
            this.Controls.Add(this.btnBart);
            this.Controls.Add(this.btnLisa);
            this.Controls.Add(this.btnHomer);
            this.Controls.Add(this.btnMarge);
            this.Controls.Add(this.btnShowNames);
            this.Name = "frmCollections";
            this.Text = "A290 Collections";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnShowNames;
        private System.Windows.Forms.Button btnMarge;
        private System.Windows.Forms.Button btnHomer;
        private System.Windows.Forms.Button btnLisa;
        private System.Windows.Forms.Button btnBart;
        private System.Windows.Forms.Button btnMaggie;
        private System.Windows.Forms.TextBox txtTheSimpsons;
    }
}

